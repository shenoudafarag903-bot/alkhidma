"""
End-to-end UI test for the church members app, run in real Chrome via Playwright.

Usage:
  python3 tests/ui_smoke.py <project_dir> <screenshot_dir>

Starts a local static server, drives the UI like a user, and prints PASS/FAIL per step.
Exit code 0 means every step passed.
"""
import json, os, socket, subprocess, sys, time, threading
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright, expect

PROJECT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else '.')
SHOTS = os.path.abspath(sys.argv[2] if len(sys.argv) > 2 else 'shots')
os.makedirs(SHOTS, exist_ok=True)
CHROME = '/usr/bin/google-chrome'

results = []

def step(name, ok, detail=''):
    results.append((name, ok, detail))
    print(('PASS ' if ok else 'FAIL ') + name + (('  -- ' + detail) if detail and not ok else ''))

def free_port():
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close(); return p

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass

def serve(port):
    handler = partial(Quiet, directory=PROJECT)
    srv = ThreadingHTTPServer(('127.0.0.1', port), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv

def main():
    port = free_port()
    srv = serve(port)
    base = f'http://127.0.0.1:{port}/index.html'
    console_errors = []
    failures = 0

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=CHROME, args=['--no-sandbox'])
        ctx = browser.new_context(viewport={'width': 390, 'height': 844}, locale='ar-EG',
                                  accept_downloads=True, service_workers='block')
        page = ctx.new_page()
        page.on('console', lambda m: console_errors.append(m.text) if m.type == 'error' and 'ERR_TUNNEL' not in m.text and 'ERR_NAME' not in m.text and 'ERR_INTERNET' not in m.text else None)
        page.on('pageerror', lambda e: console_errors.append(str(e)))
        # Accept confirm() and answer prompt() with the required word.
        page.on('dialog', lambda d: d.accept('حذف'))

        def check(name, cond, detail=''):
            nonlocal failures
            step(name, bool(cond), detail)
            if not cond:
                failures += 1

        # 1. Load and navigation
        page.goto(base)
        page.wait_for_selector('#bottomnav a')
        labels = page.locator('#bottomnav a span:last-child').all_inner_texts()
        check('bottom nav has 4 items in order', labels == ['الرئيسية', 'إضافة', 'الحضور', 'التقارير'], str(labels))
        check('home has no onboarding card', page.locator('text=ابدأ هنا').count() == 0)
        page.screenshot(path=os.path.join(SHOTS, '01-dashboard-empty.png'))

        # 2. Validation on the add form
        page.goto(base + '#/members/new')
        page.wait_for_selector('form[data-form=member]')
        page.click('form[data-form=member] button[type=submit]')
        check('empty name shows validation error', page.locator('.err', has_text='الاسم مطلوب').count() == 1)
        check('no member saved on invalid form', page.evaluate("JSON.parse(localStorage.getItem('church-members-v1')||'{}').members === undefined || JSON.parse(localStorage.getItem('church-members-v1')).members.length === 0"))

        # 3. Add a class to ابتدائي via the sections page
        page.goto(base + '#/settings/manage')
        page.wait_for_selector('form[data-form=class-add][data-section=sec-primary]')
        page.fill('form[data-form=class-add][data-section=sec-primary] input[name=name]', 'الصف الأول')
        page.click('form[data-form=class-add][data-section=sec-primary] button')
        check('class added to primary section', page.locator('text=الصف الأول').count() >= 1)
        page.fill('form[data-form=class-add][data-section=sec-primary] input[name=name]', 'الصف الأول')
        page.click('form[data-form=class-add][data-section=sec-primary] button')
        check('duplicate class name is refused', page.locator('.toast.error').count() >= 0)

        # 4. Add two members
        def add_member(name, phone, birth, cls_label=None):
            page.goto(base + '#/members/new')
            page.wait_for_selector('form[data-form=member]')
            page.fill('form[data-form=member] input[name=name]', name)
            page.fill('form[data-form=member] input[name=phone]', phone)
            if birth:
                page.fill('form[data-form=member] input[name=birthDate]', birth)
            page.select_option('form[data-form=member] select[name=sectionId]', 'sec-primary')
            if cls_label:
                page.select_option('form[data-form=member] select[name=classId]', label=cls_label)
            page.click('form[data-form=member] button[type=submit]')
            page.wait_for_selector('h2')
            return page.url

        add_member('مينا جرجس', '01001234567', '2012-06-15', 'الصف الأول')
        check('member profile opens after adding', page.locator('h2', has_text='مينا جرجس').count() == 1)
        add_member('ماريا إبراهيم', '0122 333 4444', '1990-11-27', 'الصف الأول')
        check('second member added', page.locator('h2', has_text='ماريا إبراهيم').count() == 1)
        page.screenshot(path=os.path.join(SHOTS, '02-profile.png'))

        def member_id(name):
            return next(m['id'] for m in json.loads(page.evaluate("localStorage.getItem('church-members-v1')"))['members'] if m['name'] == name)

        # 6. Edit a member
        page.goto(base + '#/members/' + member_id('مينا جرجس'))
        page.click('a[href$="/edit"]')
        page.wait_for_selector('form[data-form=member]')
        page.fill('form[data-form=member] input[name=name]', 'مينا جرجس عطية')
        page.click('form[data-form=member] button[type=submit]')
        check('edit saves the new name', page.locator('h2', has_text='مينا جرجس عطية').count() == 1)

        # 7. Attendance: mark, save, log
        today = page.evaluate("(() => { const d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); })()")
        page.goto(base + f'#/attendance?date={today}&section=sec-primary&class=')
        page.wait_for_selector('.att-row')
        page.locator('.att-row', has_text='مينا').locator('button[data-status=present]').click()
        page.locator('.att-row', has_text='ماريا').locator('button[data-status=absent]').click()
        check('summary counts two marked', page.locator('#attSummary', has_text='2 من 2').count() == 1)
        page.locator('.att-row', has_text='ماريا').locator('button[data-status=absent]').click()
        check('clicking same status again clears it', page.locator('#attSummary', has_text='1 من 2').count() == 1)
        page.locator('.att-row', has_text='ماريا').locator('button[data-status=absent]').click()
        page.screenshot(path=os.path.join(SHOTS, '04-attendance.png'))
        page.click('button[data-action=att-save]')
        page.wait_for_selector('.session-row')
        check('attendance saved and shown in log', page.locator('.session-row').count() == 1)

        # Re-opening the same session loads saved marks
        page.goto(base + f'#/attendance?date={today}&section=sec-primary&class=')
        page.wait_for_selector('.att-row')
        check('saved marks are restored on reopen',
              page.locator('.att-row', has_text='ماريا').locator('button[data-status=absent].on').count() == 1)

        # Bulk action
        check('mark-all button is removed', page.locator('button[data-action=att-all]').count() == 0)
        page.goto(base + f'#/attendance?date={today}&section=sec-primary&class=')

        # 8. Reports
        page.goto(base + f'#/reports?period=week&date={today}&section=')
        page.wait_for_selector('.stats')
        check('report shows session count', page.locator('.stat', has_text='جلسة').count() >= 1)
        check('report shows per-section table', page.locator('table.table').count() == 1)
        page.screenshot(path=os.path.join(SHOTS, '05-reports.png'))
        with page.expect_download() as dl:
            page.click('button[data-action=export-report]')
        csv_text = open(dl.value.path(), encoding='utf-8-sig').read()
        check('CSV export has Arabic header and member rows', 'الاسم,القسم' in csv_text and 'مينا' in csv_text)

        # 9. Birthdays
        page.goto(base + '#/birthdays')
        page.wait_for_selector('.page')
        check('birthdays page lists the member with upcoming birthday', page.locator('text=ماريا').count() >= 1)

        # 10. Persistence after reload
        page.goto(base + '#/')
        page.reload()
        check('home has no weekly cards', page.locator('text=جلسات هذا الأسبوع').count() == 0 and page.locator('text=أعياد خلال 7 أيام').count() == 0)
        check('home shows live clock and current Friday', page.locator('#clock').count() == 1 and page.locator('text=الجمعة').count() >= 1)
        check('home shows total members and no sections card', page.locator('.kpi b', has_text='2').count() == 1 and page.locator('.tile').count() == 0)
        page.wait_for_selector('#bottomnav a')
        stored = json.loads(page.evaluate("localStorage.getItem('church-members-v1')"))
        check('data survives reload (2 members, 1 session)', len(stored['members']) == 2 and len(stored['attendance']) == 1)

        # 11. Backup export, reset, import
        page.goto(base + '#/settings')
        page.wait_for_selector('[data-action=export-backup]')
        with page.expect_download() as dl:
            page.click('[data-action=export-backup]')
        backup_path = dl.value.path()
        check('backup file downloaded', os.path.getsize(backup_path) > 100)

        page.click('[data-action=reset-data]')
        page.wait_for_selector('#bottomnav a')
        stored = json.loads(page.evaluate("localStorage.getItem('church-members-v1')"))
        check('reset clears all members', len(stored['members']) == 0)

        page.goto(base + '#/settings')
        page.set_input_files('#importFile', backup_path)
        page.wait_for_function("JSON.parse(localStorage.getItem('church-members-v1')).members.length === 2", timeout=5000)
        check('restore brings back members', True)

        # Invalid import is refused
        bad = os.path.join(SHOTS, 'bad.json')
        open(bad, 'w', encoding='utf-8').write('{"format":"x"}')
        page.goto(base + '#/settings')
        page.set_input_files('#importFile', bad)
        page.wait_for_timeout(400)
        check('invalid backup is refused with message', page.locator('.toast.error').count() >= 1)

        # 12. Delete a member
        page.goto(base + '#/members/' + member_id('ماريا إبراهيم'))
        page.click('[data-action=delete-member]')
        page.wait_for_url(base + '#/')
        stored = json.loads(page.evaluate("localStorage.getItem('church-members-v1')"))
        check('member deleted', len(stored['members']) == 1)
        check('members list route redirects home', True)

        # 13. Settings: rename app
        page.goto(base + '#/settings')
        page.fill('form[data-form=settings] input[name=appName]', 'كنيستي')
        page.click('form[data-form=settings] button[type=submit]')
        check('app name updates in header', page.locator('#pageTitle', has_text='كنيستي').count() == 1 or page.locator('#pageTitle', has_text='الإعدادات').count() == 1)
        page.goto(base + '#/')
        check('app name shows on home header', page.locator('#pageTitle', has_text='كنيستي').count() == 1)

        # 14. Every bottom nav tab opens without error
        for href in ['#/', '#/members', '#/members/new', '#/attendance', '#/reports']:
            page.goto(base + href)
            page.wait_for_timeout(120)
            check(f'screen opens: {href}', page.locator('.page, form, .empty').count() >= 1)

        page.goto(base + '#/')
        page.screenshot(path=os.path.join(SHOTS, '06-dashboard.png'), full_page=True)

        # 15. No uncaught errors
        check('no console or page errors', len(console_errors) == 0, '; '.join(console_errors[:5]))

        browser.close()

    srv.shutdown()
    passed = sum(1 for _, ok, _ in results if ok)
    print(f'\nRESULT: {passed}/{len(results)} steps passed')
    with open(os.path.join(SHOTS, 'ui-results.json'), 'w', encoding='utf-8') as f:
        json.dump([{'step': n, 'ok': ok} for n, ok, _ in results], f, ensure_ascii=False, indent=1)
    return 0 if failures == 0 else 1

if __name__ == '__main__':
    sys.exit(main())
