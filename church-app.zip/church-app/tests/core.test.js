'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../js/core.js');

const NOW = new Date(2026, 10, 24, 20, 0, 0); // Tue 24 Nov 2026

function base() {
  const d = C.emptyData();
  const addCls = C.addClass(d, 'sec-primary', 'الصف الأول');
  assert.ok(addCls.ok);
  return { d, cls: addCls.classItem };
}

test('default sections are the four required ones', () => {
  const names = C.emptyData().sections.map(s => s.name);
  assert.deepEqual(names, ['ابتدائي', 'إعدادي وثانوي', 'سيدات', 'عام']);
});

test('adds a valid member', () => {
  const { d, cls } = base();
  const r = C.addMember(d, { name: '  مينا  جرجس ', phone: '0100 123 4567', birthDate: '2010-05-03', sectionId: 'sec-primary', classId: cls.id }, NOW);
  assert.ok(r.ok);
  assert.equal(r.member.name, 'مينا  جرجس');
  assert.equal(d.members.length, 1);
});

test('rejects empty name, bad phone, future birthdate, missing section', () => {
  const { d } = base();
  const r = C.addMember(d, { name: '  ', phone: 'abc', birthDate: '2030-01-01', sectionId: 'nope' }, NOW);
  assert.equal(r.ok, false);
  assert.ok(r.errors.name);
  assert.ok(r.errors.phone);
  assert.ok(r.errors.birthDate);
  assert.ok(r.errors.sectionId);
  assert.equal(d.members.length, 0);
});

test('rejects a class that does not belong to the chosen section', () => {
  const { d, cls } = base();
  const other = C.addClass(d, 'sec-women', 'فصل السيدات').classItem;
  const r = C.addMember(d, { name: 'أ ب', sectionId: 'sec-primary', classId: other.id }, NOW);
  assert.ok(r.errors.classId);
  const ok = C.addMember(d, { name: 'أ ب', sectionId: 'sec-primary', classId: cls.id }, NOW);
  assert.ok(ok.ok);
});

test('updates keep createdAt and change updatedAt', () => {
  const { d } = base();
  const created = C.addMember(d, { name: 'أحمد', sectionId: 'sec-general' }, NOW).member;
  const later = new Date(2026, 10, 25);
  const r = C.updateMember(d, created.id, { name: 'أحمد علي', sectionId: 'sec-general' }, later);
  assert.ok(r.ok);
  assert.equal(r.member.name, 'أحمد علي');
  assert.equal(r.member.createdAt, created.createdAt);
  assert.notEqual(r.member.updatedAt, created.updatedAt);
});

test('deleting a member removes their marks and empty sessions', () => {
  const { d } = base();
  const a = C.addMember(d, { name: 'أ', sectionId: 'sec-general' }, NOW).member;
  const b = C.addMember(d, { name: 'ب', sectionId: 'sec-general' }, NOW).member;
  C.saveSession(d, { date: '2026-11-22', sectionId: 'sec-general', marks: { [a.id]: 'present', [b.id]: 'absent' } }, NOW);
  C.saveSession(d, { date: '2026-11-15', sectionId: 'sec-general', marks: { [a.id]: 'present' } }, NOW);
  C.deleteMember(d, a.id);
  assert.equal(d.members.length, 1);
  assert.equal(d.attendance.length, 1);
  assert.deepEqual(d.attendance[0].marks, { [b.id]: 'absent' });
});

test('sections in use cannot be deleted; empty ones can', () => {
  const { d } = base();
  C.addMember(d, { name: 'أ', sectionId: 'sec-general' }, NOW);
  assert.equal(C.deleteSection(d, 'sec-general').ok, false);
  assert.equal(C.deleteSection(d, 'sec-women').ok, true);
  assert.equal(d.sections.some(s => s.id === 'sec-women'), false);
});

test('duplicate section and class names are rejected', () => {
  const { d } = base();
  assert.equal(C.addSection(d, 'عام').ok, false);
  assert.equal(C.addSection(d, 'قسم جديد').ok, true);
  assert.equal(C.addClass(d, 'sec-primary', 'الصف الأول').ok, false);
});

test('saveSession keeps only in-scope members and replaces the same session', () => {
  const { d, cls } = base();
  const a = C.addMember(d, { name: 'أ', sectionId: 'sec-primary', classId: cls.id }, NOW).member;
  const b = C.addMember(d, { name: 'ب', sectionId: 'sec-primary' }, NOW).member;
  const x = C.addMember(d, { name: 'س', sectionId: 'sec-women' }, NOW).member;

  let r = C.saveSession(d, { date: '2026-11-22', sectionId: 'sec-primary', classId: cls.id,
    marks: { [a.id]: 'present', [b.id]: 'present', [x.id]: 'absent' } }, NOW);
  assert.ok(r.ok);
  assert.deepEqual(Object.keys(r.session.marks), [a.id]);

  r = C.saveSession(d, { date: '2026-11-22', sectionId: 'sec-primary', classId: cls.id, marks: { [a.id]: 'excused' } }, NOW);
  assert.equal(d.attendance.length, 1, 'same session is replaced, not duplicated');
  assert.equal(d.attendance[0].marks[a.id], 'excused');
});

test('saveSession rejects empty marks and invalid date', () => {
  const { d } = base();
  assert.equal(C.saveSession(d, { date: '2026-11-22', sectionId: 'sec-primary', marks: {} }, NOW).ok, false);
  assert.equal(C.saveSession(d, { date: '2026-02-31', sectionId: 'sec-primary', marks: { x: 'present' } }, NOW).ok, false);
});

test('week range starts on Saturday; month range covers the whole month', () => {
  // 24 Nov 2026 is a Tuesday; the Saturday-start week is 21–27 Nov.
  assert.deepEqual(C.rangeFor('week', '2026-11-24'), { from: '2026-11-21', to: '2026-11-27' });
  // A Saturday itself starts its own week.
  assert.deepEqual(C.rangeFor('week', '2026-11-21'), { from: '2026-11-21', to: '2026-11-27' });
  // A Friday ends the week.
  assert.deepEqual(C.rangeFor('week', '2026-11-27'), { from: '2026-11-21', to: '2026-11-27' });
  assert.deepEqual(C.rangeFor('month', '2026-11-24'), { from: '2026-11-01', to: '2026-11-30' });
  assert.deepEqual(C.rangeFor('month', '2028-02-10'), { from: '2028-02-01', to: '2028-02-29' });
});

test('report computes totals, rate, per-section rate and repeat absentees', () => {
  const { d } = base();
  const a = C.addMember(d, { name: 'أ', sectionId: 'sec-primary' }, NOW).member;
  const b = C.addMember(d, { name: 'ب', sectionId: 'sec-primary' }, NOW).member;
  const dates = ['2026-11-22', '2026-11-25', '2026-11-26'];
  dates.forEach(date => C.saveSession(d, { date, sectionId: 'sec-primary', marks: { [a.id]: 'absent', [b.id]: 'present' } }, NOW));
  // Outside the range; must not be counted.
  C.saveSession(d, { date: '2026-10-01', sectionId: 'sec-primary', marks: { [a.id]: 'present' } }, NOW);

  const rep = C.buildReport(d, '2026-11-21', '2026-11-27', '');
  assert.equal(rep.sessions, 3);
  assert.deepEqual(rep.totals, { present: 3, absent: 3, excused: 0 });
  assert.equal(rep.rate, 50);
  assert.equal(rep.bySection.find(s => s.id === 'sec-primary').rate, 50);
  assert.equal(rep.absentees.length, 1);
  assert.equal(rep.absentees[0].name, 'أ');
});

test('birthdays: next occurrence, days remaining, and age turning', () => {
  const nb = C.nextBirthday('2000-11-30', NOW);
  assert.equal(nb.days, 6);
  assert.equal(nb.turns, 26);
  const past = C.nextBirthday('1990-11-01', NOW); // already passed this year
  assert.equal(past.date.getFullYear(), 2027);
  assert.equal(C.ageOn('2000-11-30', NOW), 25);
  assert.equal(C.ageOn('2000-11-24', NOW), 26);
});

test('upcoming birthdays are filtered by window and sorted', () => {
  const { d } = base();
  C.addMember(d, { name: 'بعيد', sectionId: 'sec-general', birthDate: '1980-12-20' }, NOW);
  C.addMember(d, { name: 'قريب', sectionId: 'sec-general', birthDate: '1980-11-26' }, NOW);
  C.addMember(d, { name: 'بدون تاريخ', sectionId: 'sec-general' }, NOW);
  const list = C.upcomingBirthdays(d.members, NOW, 30);
  assert.deepEqual(list.map(x => x.member.name), ['قريب', 'بعيد'].slice(0, list.length));
  assert.equal(list[0].member.name, 'قريب');
  assert.equal(list.length, 2);
});

test('search ignores tashkeel and alef/ya/ta-marbuta variants and matches phone', () => {
  const { d } = base();
  C.addMember(d, { name: 'إبراهيم ألفي', phone: '01001234567', sectionId: 'sec-general' }, NOW);
  C.addMember(d, { name: 'مريم', sectionId: 'sec-general' }, NOW);
  assert.equal(C.filterMembers(d.members, { q: 'ابراهيم' }).length, 1);
  assert.equal(C.filterMembers(d.members, { q: 'إِبْرَاهِيم' }).length, 1);
  assert.equal(C.filterMembers(d.members, { q: '01001234567' }).length, 1);
  assert.equal(C.filterMembers(d.members, { q: 'غير موجود' }).length, 0);
  assert.equal(C.filterMembers(d.members, { sectionId: 'sec-women' }).length, 0);
});

test('backup round-trip preserves data; invalid files are rejected', () => {
  const { d, cls } = base();
  const m = C.addMember(d, { name: 'نور', sectionId: 'sec-primary', classId: cls.id, notes: 'ملاحظة' }, NOW).member;
  C.saveSession(d, { date: '2026-11-22', sectionId: 'sec-primary', classId: cls.id, marks: { [m.id]: 'present' } }, NOW);

  const text = C.exportBackup(d, NOW);
  const res = C.importBackup(text);
  assert.ok(res.ok, res.error);
  assert.deepEqual(res.data.members, d.members);
  assert.deepEqual(res.data.attendance, d.attendance);
  assert.deepEqual(res.data.classes, d.classes);

  assert.equal(C.importBackup('{not json').ok, false);
  assert.equal(C.importBackup(JSON.stringify({ hello: 1 })).ok, false);
  const broken = JSON.parse(text);
  broken.members[0].sectionId = 'missing';
  assert.equal(C.importBackup(JSON.stringify(broken)).ok, false);
  const badMarks = JSON.parse(text);
  badMarks.attendance[0].marks[m.id] = 'late';
  assert.equal(C.importBackup(JSON.stringify(badMarks)).ok, false);
  const dupIds = JSON.parse(text);
  dupIds.members.push(Object.assign({}, dupIds.members[0]));
  assert.equal(C.importBackup(JSON.stringify(dupIds)).ok, false);
});

test('CSV has a BOM, quotes special characters, and uses Arabic headers', () => {
  const { d } = base();
  C.addMember(d, { name: 'أحمد, "الكبير"', sectionId: 'sec-primary' }, NOW);
  const rep = C.buildReport(d, '2026-11-21', '2026-11-27', '');
  const csv = C.toCSV(C.memberRows(d, rep, ''));
  assert.equal(csv.charCodeAt(0), 0xFEFF);
  assert.ok(csv.includes('"أحمد, ""الكبير"""'));
  assert.ok(csv.startsWith('﻿الاسم,القسم,الفصل,حاضر,غائب,بعذر,نسبة الحضور'));
});

test('deleting a class unassigns members and drops its sessions', () => {
  const { d, cls } = base();
  const m = C.addMember(d, { name: 'أ', sectionId: 'sec-primary', classId: cls.id }, NOW).member;
  C.saveSession(d, { date: '2026-11-22', sectionId: 'sec-primary', classId: cls.id, marks: { [m.id]: 'present' } }, NOW);
  C.deleteClass(d, cls.id);
  assert.equal(d.members[0].classId, '');
  assert.equal(d.attendance.length, 0);
  assert.equal(d.classes.length, 0);
});

test('current Friday: this Friday from Tue–Fri, switches to next Friday on Saturday', () => {
  assert.equal(C.currentFriday(new Date(2026, 10, 24)), '2026-11-27'); // Tue -> Fri 27
  assert.equal(C.currentFriday(new Date(2026, 10, 27, 23, 59)), '2026-11-27'); // Friday itself
  assert.equal(C.currentFriday(new Date(2026, 10, 28, 0, 1)), '2026-12-04'); // Saturday -> next Friday
  assert.equal(C.currentFriday(new Date(2026, 9, 31)), '2026-11-06'); // Sat 31 Oct -> first Friday of Nov
});

test('consecutive absentees: absent in the last two recorded Fridays only', () => {
  const { d } = base();
  const a = C.addMember(d, { name: 'أ', sectionId: 'sec-general' }, NOW).member;
  const b = C.addMember(d, { name: 'ب', sectionId: 'sec-general' }, NOW).member;
  // Fridays: 6, 13, 20 Nov 2026
  C.saveSession(d, { date: '2026-11-06', sectionId: 'sec-general', marks: { [a.id]: 'absent', [b.id]: 'absent' } }, NOW);
  C.saveSession(d, { date: '2026-11-13', sectionId: 'sec-general', marks: { [a.id]: 'absent', [b.id]: 'present' } }, NOW);
  C.saveSession(d, { date: '2026-11-20', sectionId: 'sec-general', marks: { [a.id]: 'absent', [b.id]: 'absent' } }, NOW);
  // A non-Friday session must not count.
  C.saveSession(d, { date: '2026-11-24', sectionId: 'sec-general', marks: { [a.id]: 'absent' } }, NOW);
  const list = C.consecutiveAbsentees(d, new Date(2026, 10, 24, 20));
  assert.deepEqual(list.map(x => x.member.name), ['أ']);
  assert.deepEqual(list[0].dates, ['2026-11-20', '2026-11-13']);
});
