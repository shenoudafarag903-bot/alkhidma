"""Generates PNG app icons with the standard library only (no Pillow needed)."""
import struct, zlib, sys, os

BG, PURPLE, WHITE = (11, 11, 16), (137, 85, 237), (248, 247, 252)

def png(size, path):
    r_disc = size * 0.293
    bar_half_w = size * 0.039
    bar_half_l = size * 0.172
    c = size / 2
    rows = []
    for y in range(size):
        row = bytearray([0])  # filter type 0
        for x in range(size):
            dx, dy = x + 0.5 - c, y + 0.5 - c
            col = BG
            if dx * dx + dy * dy <= r_disc * r_disc:
                col = PURPLE
                in_v = abs(dx) <= bar_half_w and abs(dy) <= bar_half_l
                in_h = abs(dy) <= bar_half_w and abs(dx) <= bar_half_l
                if in_v or in_h:
                    col = WHITE
            row += bytes(col)
        rows.append(bytes(row))
    raw = b''.join(rows)
    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)
    data = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', size, size, 8, 2, 0, 0, 0))
    data += chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b'')
    with open(path, 'wb') as f:
        f.write(data)

out = sys.argv[1] if len(sys.argv) > 1 else 'icons'
os.makedirs(out, exist_ok=True)
png(192, os.path.join(out, 'icon-192.png'))
png(512, os.path.join(out, 'icon-512.png'))
print('icons written to', out)
