// Builds dist/church-members-standalone.html: one file with CSS and JS inlined.
// Works by opening the file directly (no server). Data still lives in that browser.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

let html = read('index.html');
const css = read('css/style.css');
const core = read('js/core.js');
const app = read('js/app.js');

html = html.replace('<link rel="stylesheet" href="css/style.css">', () => '<style>\n' + css + '\n</style>');
html = html.replace('<script src="js/core.js"></script>', () => '<script>\n' + core + '\n</script>');
html = html.replace('<script src="js/app.js"></script>', () => '<script>\n' + app + '\n</script>');
html = html.replace(/<link rel="manifest"[^>]*>\n?/, '');
if (/src="js\/|href="css\//.test(html)) throw new Error('Unresolved local reference in standalone build');

const out = path.join(root, 'dist', 'church-members-standalone.html');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html, 'utf8');
console.log('wrote', out, fs.statSync(out).size, 'bytes');
