Build the APK
- Every push to main builds an APK automatically.
- Go to the repo's Actions tab, open the latest "Build APK" run, and download "alkhidma-apk" from Artifacts.
