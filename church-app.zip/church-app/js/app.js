(function () {
  'use strict';

  var C = window.Core;
  var KEY = 'church-members-v1';
  var META_KEY = 'church-members-meta';
  var app = document.getElementById('app');
  var toastEl = document.getElementById('toast');
  var data = load();
  var draft = { key: '', date: '', sectionId: '', classId: '', marks: {} };
  var reportState = { period: 'week', date: '', section: '', from: '', to: '' };
  var deferredPrompt = null;
  var toastTimer = null;
  var lastFriday = C.currentFriday(new Date());

  var ICONS = {
    home: '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    clipboard: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M9 14l2 2 4-4"/>',
    chart: '<path d="M3 3v18h18"/><path d="M7 14l4-4 3 3 5-6"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    cake: '<rect x="3" y="11" width="18" height="10" rx="2"/><path d="M3 15c1.5 1 3 1 4.5 0s3-1 4.5 0 3 1 4.5 0 3-1 4.5 0M8 11V7M12 11V7M16 11V7"/>',
    back: '<path d="M9 18l6-6-6-6"/>',
    chev: '<path d="M15 18l-6-6 6-6"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
    folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>'
  };

  var ORDINALS = ['', 'الأولى', 'الثانية', 'الثالثة', 'الرابعة', 'الخامسة'];

  /* ---------- Helpers ---------- */

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function icon(name) {
    return '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + ICONS[name] + '</svg>';
  }

  var dateFmt = new Intl.DateTimeFormat('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' });
  var monthFmt = new Intl.DateTimeFormat('ar-EG', { month: 'long' });
  var weekdayDateFmt = new Intl.DateTimeFormat('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  var timeFmt = new Intl.DateTimeFormat('ar-EG', { hour: '2-digit', minute: '2-digit' });

  function fmtDate(iso) {
    var d = C.parseISO(iso);
    return d ? dateFmt.format(d) : '—';
  }

  // "الجمعة الرابعة من نوفمبر"
  function fridayLabel(iso) {
    var d = C.parseISO(iso);
    if (!d) return '';
    return 'الجمعة ' + ORDINALS[Math.ceil(d.getDate() / 7)] + ' من ' + monthFmt.format(d);
  }

  function todayISO() { return C.isoDate(new Date()); }

  function pct(r) { return r == null ? '—' : r + '%'; }

  function sectionName(id) {
    var s = data.sections.find(function (x) { return x.id === id; });
    return s ? s.name : '—';
  }

  function className(id) {
    var c = data.classes.find(function (x) { return x.id === id; });
    return c ? c.name : '';
  }

  function classesOf(sectionId) {
    return data.classes.filter(function (c) { return c.sectionId === sectionId; });
  }

  function initials(name) {
    return name.split(/\s+/).filter(Boolean).slice(0, 2).map(function (w) { return w.charAt(0); }).join('');
  }

  function sessionSort(a, b) {
    return b.date.localeCompare(a.date) || (b.updatedAt || '').localeCompare(a.updatedAt || '');
  }

  function formValues(form) {
    var o = {};
    Array.prototype.forEach.call(form.elements, function (el) { if (el.name) o[el.name] = el.value; });
    return o;
  }

  function sectionOptionsHtml(selected) {
    return data.sections.map(function (s) {
      return '<option value="' + esc(s.id) + '"' + (s.id === selected ? ' selected' : '') + '>' + esc(s.name) + '</option>';
    }).join('');
  }

  function classOptionsHtml(sectionId, selected, emptyLabel) {
    var head = '<option value="">' + esc(emptyLabel) + '</option>';
    return head + classesOf(sectionId).map(function (c) {
      return '<option value="' + esc(c.id) + '"' + (c.id === selected ? ' selected' : '') + '>' + esc(c.name) + '</option>';
    }).join('');
  }

  function chip(id, label, on, action) {
    return '<button type="button" class="chip' + (on ? ' on' : '') + '" data-action="' + action + '" data-id="' + esc(id) + '">' + esc(label) + '</button>';
  }

  function toast(msg, isError) {
    toastEl.textContent = msg;
    toastEl.className = 'toast show' + (isError ? ' error' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.className = 'toast'; }, 2600);
  }

  function downloadText(name, text, type) {
    var blob = new Blob([text], { type: type });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1000);
  }

  function emptyState(title, actionHtml) {
    return '<div class="empty"><p>' + esc(title) + '</p>' + (actionHtml || '') + '</div>';
  }

  function stat(value, label) {
    return '<div class="stat"><b>' + esc(value) + '</b><span>' + esc(label) + '</span></div>';
  }

  function field(label, name, value, opt) {
    opt = opt || {};
    var err = opt.error ? '<small class="err">' + esc(opt.error) + '</small>' : '';
    var attrs = opt.attrs || '';
    var input;
    if (opt.options !== undefined) {
      input = '<select name="' + name + '" ' + attrs + '>' + opt.options + '</select>';
    } else {
      input = '<input name="' + name + '" type="' + (opt.type || 'text') + '" value="' + esc(value) + '" ' + attrs + '>';
    }
    return '<label class="field"><span>' + esc(label) + (opt.required ? ' *' : '') + '</span>' + input + err + '</label>';
  }

  /* ---------- Storage ---------- */

  function load() {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { return C.emptyData(); }
    if (!raw) return C.emptyData();
    try {
      var parsed = JSON.parse(raw);
      var err = C.validateData(parsed);
      if (err) throw new Error(err);
      return C.normalizeData(parsed);
    } catch (e) {
      console.error(e);
      try { localStorage.setItem(KEY + '-damaged-' + Date.now(), raw); } catch (_) { /* ignore */ }
      setTimeout(function () {
        toast('تعذر قراءة البيانات المحفوظة، وتم حفظ نسخة منها. استعد نسخة احتياطية من الإعدادات.', true);
      }, 400);
      return C.emptyData();
    }
  }

  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
      return true;
    } catch (e) {
      toast('تعذر الحفظ. مساحة التخزين ممتلئة أو متوقفة. صدّر نسخة احتياطية الآن.', true);
      return false;
    }
  }

  /* ---------- Layout ---------- */

  function renderShell() {
    var nav = [
      { key: 'home', href: '#/', icon: 'home', label: 'الرئيسية' },
      { key: 'add', href: '#/members/new', icon: 'plus', label: 'إضافة', cls: 'add' },
      { key: 'attendance', href: '#/attendance', icon: 'clipboard', label: 'الحضور' },
      { key: 'reports', href: '#/reports', icon: 'chart', label: 'التقارير' }
    ];
    document.getElementById('bottomnav').innerHTML = nav.map(function (n) {
      return '<a href="' + n.href + '" data-nav="' + n.key + '" class="' + (n.cls || '') + '">' +
        '<span class="nav-ic">' + icon(n.icon) + '</span><span>' + n.label + '</span></a>';
    }).join('');
    document.getElementById('settingsLink').innerHTML = icon('gear');
    document.getElementById('backBtn').innerHTML = icon('back');
  }

  function setHeader(title, backHref) {
    document.getElementById('pageTitle').textContent = title;
    var b = document.getElementById('backBtn');
    if (backHref) { b.setAttribute('href', backHref); b.hidden = false; }
    else { b.hidden = true; }
    document.title = title + ' · ' + data.settings.appName;
  }

  /* ---------- Router ---------- */

  function route() {
    var raw = location.hash.replace(/^#/, '') || '/';
    var qi = raw.indexOf('?');
    var path = qi >= 0 ? raw.slice(0, qi) : raw;
    var params = new URLSearchParams(qi >= 0 ? raw.slice(qi + 1) : '');
    var parts = path.split('/').filter(Boolean);
    var nav = '';
    var html = '';

    if (!parts.length) {
      nav = 'home'; setHeader(data.settings.appName, null); html = viewDashboard();
    } else if (parts[0] === 'members') {
      nav = 'add';
      if (!parts[1]) { location.replace('#/'); return; }
      if (parts[1] === 'new') {
        setHeader('مخدوم جديد', '#/members'); html = viewMemberForm(null, null, null);
      } else if (parts[1] && parts[2] === 'edit') {
        setHeader('تعديل البيانات', '#/members/' + parts[1]); html = viewMemberForm(parts[1], null, null);
      } else if (parts[1]) {
        setHeader('الملف الشخصي', '#/members'); html = viewProfile(parts[1]);
      } else {
      }
    } else if (parts[0] === 'attendance') {
      nav = 'attendance';
      if (parts[1] === 'log') { location.replace('#/attendance'); return; }
      setHeader('الحضور', null); html = viewAttendance(params);
    } else if (parts[0] === 'reports') {
      nav = 'reports'; setHeader('التقارير', null); html = viewReports(params);
    } else if (parts[0] === 'birthdays') {
      nav = 'home'; setHeader('أعياد الميلاد', '#/'); html = viewBirthdays();
    } else if (parts[0] === 'settings') {
      nav = 'settings';
      if (parts[1] === 'manage') { setHeader('الأقسام والفصول', '#/settings'); html = viewManage(); }
      else { setHeader('الإعدادات', '#/'); html = viewSettings(); }
    } else {
      setHeader('غير موجود', '#/');
      html = emptyState('الصفحة غير موجودة', '<a class="btn ghost" href="#/">الرئيسية</a>');
    }

    app.innerHTML = html;
    document.querySelectorAll('[data-nav]').forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('data-nav') === nav);
    });
    window.scrollTo(0, 0);
  }

  /* ---------- Views: Home ---------- */

  function viewDashboard() {
    var now = new Date();
    var friISO = C.currentFriday(now);
    var soon = C.upcomingBirthdays(data.members, now, 14).slice(0, 5);
    var absent = C.consecutiveAbsentees(data, now);

    var birthdays = soon.length
      ? '<ul class="list plain">' + soon.map(function (b) {
          return '<li class="row static"><span class="avatar sm">' + esc(initials(b.member.name)) + '</span>' +
            '<span class="row-main"><strong>' + esc(b.member.name) + '</strong><small>يكمل ' + b.turns + ' عامًا</small></span>' +
            '<span class="badge present">' + dayLabel(b.days) + '</span></li>';
        }).join('') + '</ul>'
      : '<p class="muted small">لا توجد أعياد خلال 14 يومًا.</p>';

    var absentHtml = absent.length
      ? '<ul class="list plain">' + absent.map(function (a) {
          return '<li class="row static"><span class="avatar sm">' + esc(initials(a.member.name)) + '</span>' +
            '<span class="row-main"><strong>' + esc(a.member.name) + '</strong><small>' + esc(sectionName(a.member.sectionId)) + '</small></span>' +
            '<span class="badge absent">جمعتين</span></li>';
        }).join('') + '</ul>'
      : '<p class="muted small">لا يوجد أحد غاب جمعتين متتاليتين.</p>';

    return '<div class="page">' +
      '<section class="card hero">' +
        '<p class="hero-day" id="todayText">' + esc(weekdayDateFmt.format(now)) + '</p>' +
        '<p class="hero-time" id="clock" dir="ltr">' + esc(timeFmt.format(now)) + '</p>' +
        '<div class="hero-friday">' +
          '<div><span class="muted small">الجمعة الحالية</span>' +
          '<strong>' + esc(fridayLabel(friISO)) + '</strong>' +
          '<span class="muted small">' + esc(fmtDate(friISO)) + '</span></div>' +
          '<a class="btn icon-only" href="#/attendance?date=' + friISO + '" aria-label="تسجيل الحضور">' + icon('clipboard') + '</a>' +
        '</div>' +
      '</section>' +
      '<section class="card kpi"><span class="muted">إجمالي المخدومين</span><b>' + data.members.length + '</b></section>' +
      '<section class="card"><h3>أعياد الميلاد القريبة</h3>' + birthdays +
        '<a class="link-more" href="#/birthdays">كل أعياد الميلاد</a></section>' +
      '<section class="card"><h3>غابوا جمعتين متتاليتين</h3>' + absentHtml + '</section>' +
      '</div>';
  }

  function dayLabel(days) {
    if (days === 0) return 'اليوم';
    if (days === 1) return 'غدًا';
    return 'بعد ' + days + ' يومًا';
  }

  function viewBirthdays() {
    var list = C.upcomingBirthdays(data.members, new Date(), 60);
    if (!list.length) {
      return '<div class="page">' + emptyState('لا توجد أعياد ميلاد خلال 60 يومًا', '<p class="muted small">تظهر هنا الأعياد لمن أدخلت تاريخ ميلاده.</p>') + '</div>';
    }
    return '<div class="page"><ul class="list">' + list.map(function (b) {
      return '<li><a class="row" href="#/members/' + esc(b.member.id) + '">' +
        '<span class="avatar">' + esc(initials(b.member.name)) + '</span>' +
        '<span class="row-main"><strong>' + esc(b.member.name) + '</strong>' +
        '<small>' + dateFmt.format(b.date) + ' · يكمل ' + b.turns + ' عامًا</small></span>' +
        '<span class="badge present">' + dayLabel(b.days) + '</span></a></li>';
    }).join('') + '</ul></div>';
  }

  /* ---------- Views: Members ---------- */

  function viewProfile(id) {
    var m = data.members.find(function (x) { return x.id === id; });
    if (!m) return emptyState('المخدوم غير موجود', '<a class="btn ghost" href="#/members">العودة للقائمة</a>');

    var age = C.ageOn(m.birthDate, new Date());
    var hist = [];
    data.attendance.forEach(function (s) {
      if (s.marks[id]) hist.push({ date: s.date, status: s.marks[id], sectionId: s.sectionId });
    });
    hist.sort(function (a, b) { return b.date.localeCompare(a.date); });
    var counts = { present: 0, absent: 0, excused: 0 };
    hist.forEach(function (h) { counts[h.status]++; });
    var cls = className(m.classId);

    var info = '<dl class="info">' +
      '<dt>الهاتف</dt><dd>' + (m.phone ? '<a dir="ltr" href="tel:' + esc(m.phone) + '">' + esc(m.phone) + '</a>' : '—') + '</dd>' +
      '<dt>تاريخ الميلاد</dt><dd>' + (m.birthDate ? fmtDate(m.birthDate) + (age != null ? ' (' + age + ' سنة)' : '') : '—') + '</dd>' +
      '</dl>';

    var histHtml = hist.length
      ? '<ul class="list plain">' + hist.slice(0, 20).map(function (h) {
          return '<li class="row static"><span class="row-main"><strong>' + fmtDate(h.date) + '</strong><small>' + esc(sectionName(h.sectionId)) + '</small></span>' +
            '<span class="badge ' + h.status + '">' + C.STATUS[h.status] + '</span></li>';
        }).join('') + '</ul>'
      : '<p class="muted">لا يوجد سجل حضور لهذا المخدوم بعد.</p>';

    return '<div class="page">' +
      '<section class="card profile-head"><span class="avatar lg">' + esc(initials(m.name)) + '</span>' +
      '<h2>' + esc(m.name) + '</h2><p class="muted">' + esc(sectionName(m.sectionId)) + (cls ? ' · ' + esc(cls) : '') + '</p></section>' +
      '<section class="card">' + info + '</section>' +
      '<div class="stats three">' + stat(counts.present, 'حضور') + stat(counts.absent, 'غياب') + stat(counts.excused, 'بعذر') + '</div>' +
      '<section class="card"><h3>سجل الحضور الأخير</h3>' + histHtml + '</section>' +
      '<div class="actions-row">' +
      '<a class="btn ghost" href="#/members/' + esc(id) + '/edit">' + icon('edit') + ' تعديل</a>' +
      '<button class="btn danger" data-action="delete-member" data-id="' + esc(id) + '">' + icon('trash') + ' حذف</button>' +
      '</div></div>';
  }

  function viewMemberForm(id, values, errors) {
    var m = id ? data.members.find(function (x) { return x.id === id; }) : null;
    if (id && !m) return emptyState('المخدوم غير موجود', '<a class="btn ghost" href="#/members">العودة للقائمة</a>');
    var v = values || (m || {
      name: '', phone: '', birthDate: '', sectionId: (data.sections[0] || {}).id || '', classId: ''
    });
    var e = errors || {};
    var secOpts = sectionOptionsHtml(v.sectionId);
    var noSections = !data.sections.length ? '<p class="err">لا توجد أقسام. أنشئ قسمًا من الإعدادات أولًا.</p>' : '';

    return '<form class="card form" data-form="member" data-id="' + esc(id || '') + '" novalidate>' +
      field('الاسم الكامل', 'name', v.name, { required: true, error: e.name, attrs: 'maxlength="80" autocomplete="off"' }) +
      field('رقم الهاتف', 'phone', v.phone, { error: e.phone, type: 'tel', attrs: 'dir="ltr" inputmode="tel"' }) +
      field('تاريخ الميلاد', 'birthDate', v.birthDate, { error: e.birthDate, type: 'date' }) +
      field('القسم', 'sectionId', v.sectionId, { required: true, error: e.sectionId, options: secOpts, attrs: 'data-change="member-section"' }) +
      field('الفصل', 'classId', v.classId, { error: e.classId, options: classOptionsHtml(v.sectionId, v.classId, 'بدون فصل') }) +
      noSections +
      '<div class="actions-row"><button class="btn" type="submit">' + (m ? 'حفظ التعديلات' : 'إضافة المخدوم') + '</button>' +
      '<a class="btn ghost" href="' + (m ? '#/members/' + esc(id) : '#/members') + '">إلغاء</a></div>' +
      '</form>';
  }

  /* ---------- Views: Attendance ---------- */

  function attListHtml() {
    var members = C.membersInScope(data, draft.sectionId, draft.classId);
    if (!members.length) {
      return emptyState('لا يوجد مخدومون في هذا القسم أو الفصل', '<a class="btn ghost" href="#/members/new">إضافة مخدوم</a>');
    }
    return '<ul class="list">' + members.map(function (m) {
      var st = draft.marks[m.id] || '';
      return '<li class="att-row"><span class="row-main"><a class="name-link" href="#/members/' + esc(m.id) + '"><strong>' + esc(m.name) + '</strong></a>' +
        '<small>' + esc(className(m.classId)) + '</small></span>' +
        '<div class="seg" role="group" aria-label="حالة الحضور">' +
        ['present', 'absent', 'excused'].map(function (s) {
          return '<button type="button" class="seg-btn ' + s + (st === s ? ' on' : '') + '" data-action="att-mark" data-id="' +
            esc(m.id) + '" data-status="' + s + '">' + C.STATUS[s] + '</button>';
        }).join('') + '</div></li>';
    }).join('') + '</ul>';
  }

  function attSummaryText() {
    var members = C.membersInScope(data, draft.sectionId, draft.classId);
    var marked = members.filter(function (m) { return draft.marks[m.id]; }).length;
    return marked + ' من ' + members.length + ' مسجّل';
  }

  function paintAttendance() {
    var list = document.getElementById('attList');
    if (!list) return;
    list.innerHTML = attListHtml();
    document.getElementById('attSummary').textContent = attSummaryText();
  }

  function viewAttendance(params) {
    if (!data.sections.length) {
      return emptyState('لا توجد أقسام بعد', '<a class="btn" href="#/settings/manage">إنشاء قسم</a>');
    }
    // Default: the Friday we are in (switches automatically on Saturday).
    var date = params.get('date');
    if (!C.parseISO(date)) date = C.currentFriday(new Date());
    var sectionId = params.get('section');
    if (!data.sections.some(function (s) { return s.id === sectionId; })) sectionId = data.sections[0].id;
    var classId = params.get('class') || '';
    if (classId && !data.classes.some(function (c) { return c.id === classId && c.sectionId === sectionId; })) classId = '';

    var key = [date, sectionId, classId].join('|');
    if (draft.key !== key) {
      var ex = C.findSession(data, date, sectionId, classId);
      draft = { key: key, date: date, sectionId: sectionId, classId: classId, marks: ex ? Object.assign({}, ex.marks) : {} };
    }

    var dateLabel = C.isFriday(date) ? fridayLabel(date) : dateFmt.format(C.parseISO(date));
    return '<div class="page">' +
      '<section class="card form compact">' +
      '<p class="friday-label">' + esc(dateLabel) + '</p>' +
      '<input type="hidden" name="date" value="' + esc(date) + '">' +
      field('القسم', 'section', sectionId, { options: sectionOptionsHtml(sectionId), attrs: 'data-change="att-scope"' }) +
      field('الفصل', 'class', classId, { options: classOptionsHtml(sectionId, classId, 'كل الفصول'), attrs: 'data-change="att-scope"' }) +
      '</section>' +
      '<div class="att-head"><span id="attSummary" class="muted small">' + esc(attSummaryText()) + '</span></div>' +
      '<div id="attList">' + attListHtml() + '</div>' +
      '<div class="actions-row sticky-actions"><button class="btn full" data-action="att-save">حفظ الحضور</button></div>' +
      '<h3 class="section-title">الجلسات المسجلة</h3>' + sessionsListHtml() +
      '</div>';
  }

  function sessionsListHtml() {
    var sessions = data.attendance.slice().sort(sessionSort);
    if (!sessions.length) return emptyState('لا توجد جلسات حضور بعد');
    return '<ul class="list">' + sessions.map(function (s) {
      var counts = { present: 0, absent: 0, excused: 0 };
      Object.keys(s.marks).forEach(function (id) { counts[s.marks[id]]++; });
      var t = counts.present + counts.absent + counts.excused;
      return '<li class="row session-row">' +
        '<a class="row-main" href="#/attendance?date=' + s.date + '&section=' + esc(s.sectionId) + '&class=' + esc(s.classId) + '">' +
        '<strong>' + fmtDate(s.date) + '</strong>' +
        '<small>' + esc(sectionName(s.sectionId)) + (s.classId ? ' · ' + esc(className(s.classId)) : '') + '</small>' +
        '<small>حاضر ' + counts.present + ' · غائب ' + counts.absent + ' · بعذر ' + counts.excused +
        (t ? ' · ' + Math.round(counts.present / t * 100) + '%' : '') + '</small></a>' +
        '<button class="icon-btn danger" data-action="del-session" data-id="' + esc(s.id) + '" aria-label="حذف الجلسة">' + icon('trash') + '</button>' +
        '</li>';
    }).join('') + '</ul>';
  }

  /* ---------- Views: Reports ---------- */

  function viewReports(params) {
    var now = new Date();
    var section = params.get('section') || '';
    if (section && !data.sections.some(function (x) { return x.id === section; })) section = '';
    var r = C.rangeFor('month', C.isoDate(now));
    var rep = C.buildReport(data, r.from, r.to, section);
    reportState = { period: 'month', date: r.from, section: section, from: r.from, to: r.to };

    var absent = rep.absentees.length
      ? '<ul class="list plain">' + rep.absentees.map(function (a) {
          return '<li class="row static"><span class="row-main"><strong>' + esc(a.name) + '</strong></span>' +
            '<span class="badge absent">' + a.absent + ' غيابات</span></li>';
        }).join('') + '</ul>'
      : '<p class="muted">لا يوجد مخدومون غابوا 3 مرات أو أكثر هذا الشهر.</p>';

    return '<div class="page">' +
      '<section class="card form compact">' +
      field('القسم', 'section', section, { options: '<option value="">كل الأقسام</option>' + sectionOptionsHtml(section), attrs: 'data-change="report-scope"' }) +
      '</section>' +
      '<p class="muted small">شهر ' + esc(monthFmt.format(now)) + ' · ' + fmtDate(r.from) + ' – ' + fmtDate(r.to) + '</p>' +
      '<div class="stats">' + stat(rep.sessions, 'جلسة') + stat(pct(rep.rate), 'نسبة الحضور') +
      stat(rep.totals.present, 'حضور') + stat(rep.totals.absent, 'غياب') + '</div>' +
      '<section class="card"><h3>حسب القسم</h3>' +
      (rep.bySection.length ? '<table class="table"><thead><tr><th>القسم</th><th>الجلسات</th><th>الحضور</th></tr></thead><tbody>' +
        rep.bySection.map(function (b) {
          return '<tr><td>' + esc(b.name) + '</td><td>' + b.sessions + '</td><td>' + pct(b.rate) + '</td></tr>';
        }).join('') + '</tbody></table>' : '<p class="muted">لا توجد أقسام.</p>') +
      '</section>' +
      '<section class="card"><h3>غياب متكرر</h3>' + absent + '</section>' +
      '<button class="btn ghost full" data-action="export-report">' + icon('download') + ' تصدير CSV</button>' +
      '</div>';
  }

  /* ---------- Views: Settings and sections ---------- */

  function viewManage() {
    var groups = data.sections.map(function (s) {
      var mc = data.members.filter(function (m) { return m.sectionId === s.id; }).length;
      var cl = classesOf(s.id);
      return '<section class="card"><div class="group-head"><strong>' + esc(s.name) + '</strong>' +
        '<span class="muted small">' + mc + ' مخدوم</span>' +
        '<span class="head-actions">' +
        '<button class="icon-btn" data-action="rename-section" data-id="' + esc(s.id) + '" aria-label="إعادة تسمية">' + icon('edit') + '</button>' +
        '<button class="icon-btn danger" data-action="delete-section" data-id="' + esc(s.id) + '" aria-label="حذف القسم">' + icon('trash') + '</button>' +
        '</span></div>' +
        (cl.length ? '<ul class="list plain">' + cl.map(function (c) {
          return '<li class="row static"><span class="row-main">' + esc(c.name) + '</span>' +
            '<span class="head-actions">' +
            '<button class="icon-btn" data-action="rename-class" data-id="' + esc(c.id) + '" aria-label="إعادة تسمية">' + icon('edit') + '</button>' +
            '<button class="icon-btn danger" data-action="delete-class" data-id="' + esc(c.id) + '" aria-label="حذف الفصل">' + icon('trash') + '</button>' +
            '</span></li>';
        }).join('') + '</ul>' : '<p class="muted small">لا توجد فصول في هذا القسم.</p>') +
        '<form class="inline-form" data-form="class-add" data-section="' + esc(s.id) + '">' +
        '<input name="name" placeholder="اسم فصل جديد" maxlength="60" required>' +
        '<button class="btn ghost" type="submit">إضافة فصل</button></form></section>';
    }).join('');

    return '<div class="page">' +
      '<section class="card"><h3>إضافة قسم</h3>' +
      '<form class="inline-form" data-form="section-add"><input name="name" placeholder="اسم القسم" maxlength="60" required>' +
      '<button class="btn" type="submit">إضافة</button></form></section>' +
      (groups || emptyState('لا توجد أقسام')) + '</div>';
  }

  function viewSettings() {
    var meta = {};
    try { meta = JSON.parse(localStorage.getItem(META_KEY) || '{}'); } catch (e) { meta = {}; }
    var last = meta.lastBackup ? fmtDate(meta.lastBackup.slice(0, 10)) : 'لم تُصدَّر نسخة بعد';

    return '<div class="page">' +
      '<form class="card form" data-form="settings">' +
      field('اسم التطبيق', 'appName', data.settings.appName, { required: true, attrs: 'maxlength="60"' }) +
      '<button class="btn" type="submit">حفظ الاسم</button></form>' +
      '<section class="card"><h3>إدارة البيانات</h3>' +
      '<a class="setting-link" href="#/settings/manage">' + icon('folder') + '<span>الأقسام والفصول</span>' + icon('chev') + '</a>' +
      '<button class="setting-link" type="button" data-action="export-backup">' + icon('download') + '<span>تصدير نسخة احتياطية</span></button>' +
      '<label class="setting-link" for="importFile">' + icon('upload') + '<span>استعادة نسخة احتياطية</span></label>' +
      '<input id="importFile" type="file" accept="application/json,.json" hidden data-change="import-file">' +
      '<button class="setting-link danger" type="button" data-action="reset-data">' + icon('trash') + '<span>مسح جميع البيانات</span></button>' +
      '</section>' +
      '<section class="card"><h3>معلومات التخزين</h3>' +
      '<p class="muted small">تُحفظ البيانات في هذا المتصفح على هذا الجهاز فقط، ولا تُزامَن تلقائيًا بين الأجهزة. للنقل بين الأجهزة استخدم النسخ الاحتياطي.</p>' +
      '<div class="stats three">' + stat(data.members.length, 'مخدوم') + stat(data.attendance.length, 'جلسة') + stat(data.classes.length, 'فصل') + '</div>' +
      '<p class="muted small">آخر نسخة احتياطية: ' + esc(last) + '</p></section>' +
      '<button class="btn ghost full" type="button" data-action="install" id="installBtn"' + (deferredPrompt ? '' : ' hidden') + '>' + icon('download') + ' تثبيت التطبيق</button>' +
      '</div>';
  }

  /* ---------- Actions and form handlers ---------- */

  var handlers = {
    member: function (form) {
      var f = formValues(form);
      var id = form.getAttribute('data-id');
      if (id) {
        // Address and notes are no longer editable here; keep whatever was stored.
        var old = data.members.find(function (x) { return x.id === id; });
        if (old) { f.address = old.address; f.notes = old.notes; }
      }
      var res = id ? C.updateMember(data, id, f) : C.addMember(data, f);
      if (!res.ok) {
        form.outerHTML = viewMemberForm(id || null, f, res.errors);
        toast('راجع الحقول المحددة', true);
        return;
      }
      if (!save()) return;
      toast(id ? 'تم تعديل البيانات' : 'تمت إضافة المخدوم');
      location.hash = '#/members/' + res.member.id;
    },
    'section-add': function (form) {
      var res = C.addSection(data, form.elements.name.value);
      if (!res.ok) return toast(res.error, true);
      if (!save()) return;
      toast('تمت إضافة القسم');
      route();
    },
    'class-add': function (form) {
      var res = C.addClass(data, form.getAttribute('data-section'), form.elements.name.value);
      if (!res.ok) return toast(res.error, true);
      if (!save()) return;
      toast('تمت إضافة الفصل');
      route();
    },
    settings: function (form) {
      var name = form.elements.appName.value.trim();
      if (!name) return toast('اسم التطبيق مطلوب', true);
      data.settings.appName = name;
      if (!save()) return;
      toast('تم حفظ الإعدادات');
      route();
    }
  };

  var actions = {
    'delete-member': function (el) {
      if (!window.confirm('حذف هذا المخدوم وكل سجلات حضوره؟ لا يمكن التراجع.')) return;
      C.deleteMember(data, el.getAttribute('data-id'));
      if (!save()) return;
      toast('تم حذف المخدوم');
      location.hash = '#/';
    },
    'att-mark': function (el) {
      var id = el.getAttribute('data-id');
      var st = el.getAttribute('data-status');
      if (draft.marks[id] === st) delete draft.marks[id];
      else draft.marks[id] = st;
      paintAttendance();
    },
    'att-save': function () {
      var res = C.saveSession(data, { date: draft.date, sectionId: draft.sectionId, classId: draft.classId, marks: draft.marks });
      if (!res.ok) return toast(res.error, true);
      if (!save()) return;
      toast('تم حفظ الحضور');
      route();
    },
    'del-session': function (el) {
      if (!window.confirm('حذف جلسة الحضور هذه؟')) return;
      C.deleteSession(data, el.getAttribute('data-id'));
      if (!save()) return;
      toast('تم حذف الجلسة');
      route();
    },
    'export-report': function () {
      var rep = C.buildReport(data, reportState.from, reportState.to, reportState.section);
      var rows = C.memberRows(data, rep, reportState.section);
      if (!rows.length) return toast('لا توجد بيانات للتصدير', true);
      downloadText('attendance-' + reportState.from + '-to-' + reportState.to + '.csv', C.toCSV(rows), 'text/csv;charset=utf-8');
    },
    'rename-section': function (el) {
      var s = data.sections.find(function (x) { return x.id === el.getAttribute('data-id'); });
      if (!s) return;
      var name = window.prompt('اسم القسم الجديد', s.name);
      if (name === null) return;
      var res = C.renameSection(data, s.id, name);
      if (!res.ok) return toast(res.error, true);
      save();
      route();
    },
    'delete-section': function (el) {
      var res = C.deleteSection(data, el.getAttribute('data-id'));
      if (!res.ok) return toast(res.error, true);
      if (!window.confirm('تم حذف القسم.')) return;
      save();
      route();
    },
    'rename-class': function (el) {
      var c = data.classes.find(function (x) { return x.id === el.getAttribute('data-id'); });
      if (!c) return;
      var name = window.prompt('اسم الفصل الجديد', c.name);
      if (name === null) return;
      var res = C.renameClass(data, c.id, name);
      if (!res.ok) return toast(res.error, true);
      save();
      route();
    },
    'delete-class': function (el) {
      if (!window.confirm('حذف الفصل؟ سيُنقل أعضاؤه إلى بدون فصل، وتُحذف جلسات الحضور الخاصة به.')) return;
      C.deleteClass(data, el.getAttribute('data-id'));
      save();
      route();
    },
    'export-backup': function () {
      var text = C.exportBackup(data, new Date());
      downloadText('church-backup-' + todayISO() + '.json', text, 'application/json;charset=utf-8');
      try { localStorage.setItem(META_KEY, JSON.stringify({ lastBackup: new Date().toISOString() })); } catch (e) { /* ignore */ }
      toast('تم تصدير النسخة الاحتياطية');
      route();
    },
    'reset-data': function () {
      if (!window.confirm('سيتم مسح كل المخدومين والحضور والأقسام. هل أنت متأكد؟')) return;
      var typed = window.prompt('للتأكيد اكتب كلمة: حذف');
      if (typed !== 'حذف') return toast('لم يتم المسح', true);
      data = C.emptyData();
      draft = { key: '', date: '', sectionId: '', classId: '', marks: {} };
      save();
      toast('تم مسح البيانات');
      location.hash = '#/';
      route();
    },
    install: function () {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      deferredPrompt = null;
    }
  };

  var changes = {
    'member-section': function (el) {
      el.form.elements.classId.innerHTML = classOptionsHtml(el.value, '', 'بدون فصل');
    },
    'att-scope': function () {
      var date = app.querySelector('input[name=date]').value;
      var sec = app.querySelector('select[name=section]').value;
      var cls = app.querySelector('select[name=class]').value;
      if (!C.parseISO(date)) return toast('التاريخ غير صحيح', true);
      location.hash = '#/attendance?date=' + date + '&section=' + sec + '&class=' + cls;
    },
    'report-scope': function () {
      var sec = app.querySelector('select[name=section]').value;
      location.hash = '#/reports' + (sec ? '?section=' + sec : '');
    },
    'import-file': function (el) {
      var file = el.files && el.files[0];
      el.value = '';
      if (!file) return;
      file.text().then(function (text) {
        var res = C.importBackup(text);
        if (!res.ok) return toast(res.error, true);
        if (!window.confirm('سيتم استبدال البيانات الحالية بالنسخة المستعادة. هل تريد المتابعة؟')) return;
        data = res.data;
        draft = { key: '', date: '', sectionId: '', classId: '', marks: {} };
        if (!save()) return;
        toast('تمت استعادة النسخة الاحتياطية');
        route();
      }).catch(function () { toast('تعذر قراءة الملف', true); });
    }
  };

  /* ---------- Live clock and automatic Friday switch ---------- */

  function tick() {
    var now = new Date();
    var clock = document.getElementById('clock');
    if (clock) {
      clock.textContent = timeFmt.format(now);
      document.getElementById('todayText').textContent = weekdayDateFmt.format(now);
    }
    var fri = C.currentFriday(now);
    if (fri !== lastFriday) {
      lastFriday = fri;
      var h = location.hash;
      var onHome = h === '' || h === '#' || h === '#/';
      var onAttendanceDefault = h.indexOf('#/attendance') === 0 && h.indexOf('date=') < 0 && h.indexOf('/log') < 0;
      if (onHome || onAttendanceDefault) route();
    }
  }

  /* ---------- Event wiring (delegation) ---------- */

  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!f.getAttribute || !f.getAttribute('data-form')) return;
    e.preventDefault();
    var h = handlers[f.getAttribute('data-form')];
    if (h) h(f);
  });

  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-action]') : null;
    if (!el) return;
    var h = actions[el.getAttribute('data-action')];
    if (h) { e.preventDefault(); h(el); }
  });

  document.addEventListener('change', function (e) {
    var key = e.target.getAttribute ? e.target.getAttribute('data-change') : null;
    if (key && changes[key]) changes[key](e.target);
  });

  window.addEventListener('hashchange', route);

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferredPrompt = e;
    var btn = document.getElementById('installBtn');
    if (btn) btn.hidden = false;
  });

  window.addEventListener('appinstalled', function () {
    deferredPrompt = null;
    toast('تم تثبيت التطبيق');
  });

  /* ---------- Start ---------- */

  renderShell();
  route();
  setInterval(tick, 1000);

  if (navigator.storage && navigator.storage.persist) {
    navigator.storage.persist().catch(function () { /* not granted: fine */ });
  }

  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('service-worker.js').catch(function (err) {
        console.warn('Service worker registration failed', err);
      });
    });
  }
})();
