/* Core logic: pure functions, no DOM. Works in the browser (window.Core) and in Node (tests). */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Core = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var STATUS = { present: 'حاضر', absent: 'غائب', excused: 'بعذر' };
  var FORMAT = 'church-members-backup';
  var LIMITS = { name: 80, short: 60, long: 500 };
  var DAY = 86400000;
  var DEFAULT_SECTIONS = [
    { id: 'sec-primary', name: 'ابتدائي' },
    { id: 'sec-secondary', name: 'إعدادي وثانوي' },
    { id: 'sec-women', name: 'سيدات' },
    { id: 'sec-general', name: 'عام' }
  ];

  function pad(n) { return String(n).padStart(2, '0'); }
  function clean(s) { return String(s == null ? '' : s).trim(); }
  function isoDate(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }

  function parseISO(s) {
    if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
    var p = s.split('-').map(Number);
    var d = new Date(p[0], p[1] - 1, p[2]);
    return (d.getFullYear() === p[0] && d.getMonth() === p[1] - 1 && d.getDate() === p[2]) ? d : null;
  }

  function uid(prefix) {
    return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  // Normalizes Arabic text for search: removes tashkeel, unifies alef/ya/ta marbuta.
  function normalizeText(s) {
    return String(s || '').toLowerCase()
      .replace(/[ً-ٰٟ]/g, '')
      .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
      .replace(/\s+/g, ' ').trim();
  }

  function byName(a, b) { return a.name.localeCompare(b.name, 'ar'); }

  function emptyData() {
    return {
      format: FORMAT,
      version: 1,
      settings: { appName: 'الخدمة' },
      sections: DEFAULT_SECTIONS.map(function (s) { return { id: s.id, name: s.name }; }),
      classes: [],
      members: [],
      attendance: []
    };
  }

  /* ---------- Validation ---------- */

  function validateName(name, label) {
    var n = clean(name);
    if (!n) return label + ' مطلوب';
    if (n.length > LIMITS.short) return label + ' طويل جدًا';
    return null;
  }

  function validateMember(m, data, now) {
    var e = {};
    var name = clean(m.name);
    if (!name) e.name = 'الاسم مطلوب';
    else if (name.length > LIMITS.name) e.name = 'الاسم طويل جدًا';

    var phone = clean(m.phone);
    if (phone && !/^[0-9+()\- ]{6,20}$/.test(phone)) e.phone = 'رقم الهاتف غير صحيح';

    if (m.birthDate) {
      var b = parseISO(m.birthDate);
      if (!b) e.birthDate = 'تاريخ الميلاد غير صحيح';
      else if (b > (now || new Date())) e.birthDate = 'تاريخ الميلاد لا يمكن أن يكون في المستقبل';
    }

    if (!data.sections.some(function (s) { return s.id === m.sectionId; })) e.sectionId = 'اختر القسم';

    if (m.classId) {
      var c = data.classes.find(function (x) { return x.id === m.classId; });
      if (!c || c.sectionId !== m.sectionId) e.classId = 'الفصل لا يتبع القسم المختار';
    }

    if (clean(m.address).length > LIMITS.long) e.address = 'العنوان طويل جدًا';
    if (clean(m.notes).length > LIMITS.long) e.notes = 'الملاحظات طويلة جدًا';
    return e;
  }

  function validateData(d) {
    if (!d || typeof d !== 'object' || Array.isArray(d)) return 'بنية الملف غير صحيحة';
    if (d.format !== FORMAT) return 'هذا الملف ليس نسخة احتياطية من هذا التطبيق';
    var keys = ['sections', 'classes', 'members', 'attendance'];
    for (var i = 0; i < keys.length; i++) {
      if (!Array.isArray(d[keys[i]])) return 'الملف ناقص: ' + keys[i];
    }

    function unique(list, label) {
      var ids = {};
      for (var j = 0; j < list.length; j++) {
        var id = list[j] && list[j].id;
        if (typeof id !== 'string' || !id) return label + ': معرّف غير صالح';
        if (ids[id]) return label + ': معرّف مكرر';
        ids[id] = true;
      }
      return null;
    }
    var err = unique(d.sections, 'الأقسام') || unique(d.classes, 'الفصول') ||
      unique(d.members, 'المخدومون') || unique(d.attendance, 'الحضور');
    if (err) return err;

    var sectionIds = {}, classIds = {};
    for (var s = 0; s < d.sections.length; s++) {
      if (validateName(d.sections[s].name, 'اسم القسم')) return 'اسم قسم غير صالح';
      sectionIds[d.sections[s].id] = true;
    }
    for (var c = 0; c < d.classes.length; c++) {
      var cl = d.classes[c];
      if (!sectionIds[cl.sectionId] || validateName(cl.name, 'اسم الفصل')) return 'فصل غير صالح';
      classIds[cl.id] = true;
    }
    for (var m = 0; m < d.members.length; m++) {
      var mem = d.members[m];
      if (Object.keys(validateMember(mem, d, new Date())).length) {
        return 'بيانات مخدوم غير صالحة: ' + (mem.name || mem.id);
      }
    }
    for (var a = 0; a < d.attendance.length; a++) {
      var at = d.attendance[a];
      if (!parseISO(at.date)) return 'تاريخ جلسة حضور غير صالح';
      if (!sectionIds[at.sectionId]) return 'جلسة حضور لقسم غير موجود';
      if (at.classId && !classIds[at.classId]) return 'جلسة حضور لفصل غير موجود';
      if (!at.marks || typeof at.marks !== 'object' || Array.isArray(at.marks)) return 'سجل حضور غير صالح';
      var ks = Object.keys(at.marks);
      for (var k = 0; k < ks.length; k++) {
        if (!STATUS[at.marks[ks[k]]]) return 'حالة حضور غير معروفة';
      }
    }
    return null;
  }

  /* ---------- Normalization ---------- */

  function toMemberRecord(input, id, createdAt, updatedAt) {
    return {
      id: id,
      name: clean(input.name),
      phone: clean(input.phone),
      birthDate: input.birthDate || '',
      sectionId: input.sectionId,
      classId: input.classId || '',
      address: clean(input.address),
      notes: clean(input.notes),
      createdAt: createdAt,
      updatedAt: updatedAt
    };
  }

  function normalizeData(d) {
    return {
      format: FORMAT,
      version: 1,
      settings: { appName: clean(d.settings && d.settings.appName) || 'الخدمة' },
      sections: d.sections.map(function (s) { return { id: String(s.id), name: clean(s.name) }; }),
      classes: d.classes.map(function (c) { return { id: String(c.id), sectionId: String(c.sectionId), name: clean(c.name) }; }),
      members: d.members.map(function (m) {
        return toMemberRecord(m, String(m.id), m.createdAt || '', m.updatedAt || '');
      }),
      attendance: d.attendance.map(function (s) {
        return {
          id: String(s.id), date: s.date, sectionId: String(s.sectionId),
          classId: s.classId ? String(s.classId) : '',
          marks: Object.assign({}, s.marks), updatedAt: s.updatedAt || ''
        };
      })
    };
  }

  /* ---------- Members ---------- */

  function addMember(data, input, now) {
    now = now || new Date();
    var errors = validateMember(input, data, now);
    if (Object.keys(errors).length) return { ok: false, errors: errors };
    var t = now.toISOString();
    var rec = toMemberRecord(input, uid('m'), t, t);
    data.members.push(rec);
    return { ok: true, member: rec };
  }

  function updateMember(data, id, input, now) {
    now = now || new Date();
    var idx = data.members.findIndex(function (m) { return m.id === id; });
    if (idx < 0) return { ok: false, errors: { name: 'المخدوم غير موجود' } };
    var errors = validateMember(input, data, now);
    if (Object.keys(errors).length) return { ok: false, errors: errors };
    var old = data.members[idx];
    data.members[idx] = toMemberRecord(input, id, old.createdAt, now.toISOString());
    return { ok: true, member: data.members[idx] };
  }

  function deleteMember(data, id) {
    data.members = data.members.filter(function (m) { return m.id !== id; });
    data.attendance.forEach(function (s) { delete s.marks[id]; });
    data.attendance = data.attendance.filter(function (s) { return Object.keys(s.marks).length > 0; });
    return { ok: true };
  }

  /* ---------- Sections and classes ---------- */

  function nameTaken(list, name, excludeId, scopeFn) {
    var n = normalizeText(name);
    return list.some(function (x) {
      return x.id !== excludeId && (!scopeFn || scopeFn(x)) && normalizeText(x.name) === n;
    });
  }

  function addSection(data, name) {
    var err = validateName(name, 'اسم القسم');
    if (err) return { ok: false, error: err };
    var n = clean(name);
    if (nameTaken(data.sections, n)) return { ok: false, error: 'اسم القسم موجود مسبقًا' };
    var s = { id: uid('sec'), name: n };
    data.sections.push(s);
    return { ok: true, section: s };
  }

  function renameSection(data, id, name) {
    var err = validateName(name, 'اسم القسم');
    if (err) return { ok: false, error: err };
    var s = data.sections.find(function (x) { return x.id === id; });
    if (!s) return { ok: false, error: 'القسم غير موجود' };
    var n = clean(name);
    if (nameTaken(data.sections, n, id)) return { ok: false, error: 'اسم القسم موجود مسبقًا' };
    s.name = n;
    return { ok: true };
  }

  function deleteSection(data, id) {
    if (data.members.some(function (m) { return m.sectionId === id; })) {
      return { ok: false, error: 'لا يمكن حذف قسم يحتوي على مخدومين. انقلهم إلى قسم آخر أولًا' };
    }
    if (data.classes.some(function (c) { return c.sectionId === id; })) {
      return { ok: false, error: 'احذف فصول هذا القسم أولًا' };
    }
    data.sections = data.sections.filter(function (s) { return s.id !== id; });
    data.attendance = data.attendance.filter(function (r) { return r.sectionId !== id; });
    return { ok: true };
  }

  function addClass(data, sectionId, name) {
    if (!data.sections.some(function (s) { return s.id === sectionId; })) return { ok: false, error: 'القسم غير موجود' };
    var err = validateName(name, 'اسم الفصل');
    if (err) return { ok: false, error: err };
    var n = clean(name);
    if (nameTaken(data.classes, n, null, function (c) { return c.sectionId === sectionId; })) {
      return { ok: false, error: 'اسم الفصل موجود مسبقًا في هذا القسم' };
    }
    var c = { id: uid('cls'), sectionId: sectionId, name: n };
    data.classes.push(c);
    return { ok: true, classItem: c };
  }

  function renameClass(data, id, name) {
    var err = validateName(name, 'اسم الفصل');
    if (err) return { ok: false, error: err };
    var c = data.classes.find(function (x) { return x.id === id; });
    if (!c) return { ok: false, error: 'الفصل غير موجود' };
    var n = clean(name);
    if (nameTaken(data.classes, n, id, function (x) { return x.sectionId === c.sectionId; })) {
      return { ok: false, error: 'اسم الفصل موجود مسبقًا في هذا القسم' };
    }
    c.name = n;
    return { ok: true };
  }

  // Deleting a class unassigns its members and removes the attendance sessions held for it.
  function deleteClass(data, id) {
    data.classes = data.classes.filter(function (c) { return c.id !== id; });
    data.members.forEach(function (m) { if (m.classId === id) m.classId = ''; });
    data.attendance = data.attendance.filter(function (s) { return s.classId !== id; });
    return { ok: true };
  }

  /* ---------- Attendance ---------- */

  function findSession(data, date, sectionId, classId) {
    return data.attendance.find(function (r) {
      return r.date === date && r.sectionId === sectionId && (r.classId || '') === (classId || '');
    }) || null;
  }

  function membersInScope(data, sectionId, classId) {
    return data.members
      .filter(function (m) { return m.sectionId === sectionId && (!classId || m.classId === classId); })
      .sort(byName);
  }

  function saveSession(data, input, now) {
    now = now || new Date();
    if (!parseISO(input.date)) return { ok: false, error: 'التاريخ غير صحيح' };
    if (!data.sections.some(function (s) { return s.id === input.sectionId; })) return { ok: false, error: 'اختر القسم' };
    var classId = input.classId || '';
    if (classId && !data.classes.some(function (c) { return c.id === classId && c.sectionId === input.sectionId; })) {
      return { ok: false, error: 'الفصل لا يتبع القسم' };
    }
    var allowed = {};
    membersInScope(data, input.sectionId, classId).forEach(function (m) { allowed[m.id] = true; });
    var marks = {};
    Object.keys(input.marks || {}).forEach(function (id) {
      if (allowed[id] && STATUS[input.marks[id]]) marks[id] = input.marks[id];
    });
    if (!Object.keys(marks).length) return { ok: false, error: 'سجّل حالة واحدة على الأقل' };

    var existing = findSession(data, input.date, input.sectionId, classId);
    var rec = {
      id: existing ? existing.id : uid('att'),
      date: input.date, sectionId: input.sectionId, classId: classId,
      marks: marks, updatedAt: now.toISOString()
    };
    if (existing) data.attendance[data.attendance.indexOf(existing)] = rec;
    else data.attendance.push(rec);
    return { ok: true, session: rec };
  }

  function deleteSession(data, id) {
    data.attendance = data.attendance.filter(function (s) { return s.id !== id; });
    return { ok: true };
  }

  /* ---------- Reports ---------- */

  // Weeks start on Saturday (the Egyptian working week).
  function rangeFor(period, anchor) {
    var d = parseISO(anchor) || new Date();
    if (period === 'month') {
      return {
        from: isoDate(new Date(d.getFullYear(), d.getMonth(), 1)),
        to: isoDate(new Date(d.getFullYear(), d.getMonth() + 1, 0))
      };
    }
    var offset = (d.getDay() + 1) % 7;
    var start = new Date(d.getFullYear(), d.getMonth(), d.getDate() - offset);
    var end = new Date(d.getFullYear(), d.getMonth(), d.getDate() - offset + 6);
    return { from: isoDate(start), to: isoDate(end) };
  }

  function buildReport(data, from, to, sectionId) {
    var sessions = data.attendance.filter(function (r) {
      return r.date >= from && r.date <= to && (!sectionId || r.sectionId === sectionId);
    });
    var totals = { present: 0, absent: 0, excused: 0 };
    var perMember = {};
    sessions.forEach(function (s) {
      Object.keys(s.marks).forEach(function (id) {
        var st = s.marks[id];
        totals[st]++;
        var pm = perMember[id] || (perMember[id] = { present: 0, absent: 0, excused: 0 });
        pm[st]++;
      });
    });
    var total = totals.present + totals.absent + totals.excused;

    var bySection = data.sections.filter(function (s) { return !sectionId || s.id === sectionId; })
      .map(function (sec) {
        var ss = sessions.filter(function (s) { return s.sectionId === sec.id; });
        var p = 0, t = 0;
        ss.forEach(function (s) {
          Object.keys(s.marks).forEach(function (id) { t++; if (s.marks[id] === 'present') p++; });
        });
        return { id: sec.id, name: sec.name, sessions: ss.length, present: p, total: t, rate: t ? Math.round(p / t * 100) : null };
      });

    var absentees = data.members
      .filter(function (m) { return perMember[m.id] && perMember[m.id].absent >= 3; })
      .map(function (m) { return { id: m.id, name: m.name, absent: perMember[m.id].absent }; })
      .sort(function (a, b) { return b.absent - a.absent; })
      .slice(0, 10);

    return {
      from: from, to: to, sessions: sessions.length, totals: totals, total: total,
      rate: total ? Math.round(totals.present / total * 100) : null,
      bySection: bySection, absentees: absentees, perMember: perMember
    };
  }

  function memberRows(data, report, sectionId) {
    return data.members
      .filter(function (m) { return !sectionId || m.sectionId === sectionId; })
      .sort(byName)
      .map(function (m) {
        var pm = report.perMember[m.id] || { present: 0, absent: 0, excused: 0 };
        var t = pm.present + pm.absent + pm.excused;
        var sec = data.sections.find(function (s) { return s.id === m.sectionId; });
        var cls = data.classes.find(function (c) { return c.id === m.classId; });
        return {
          'الاسم': m.name,
          'القسم': sec ? sec.name : '',
          'الفصل': cls ? cls.name : '',
          'حاضر': pm.present,
          'غائب': pm.absent,
          'بعذر': pm.excused,
          'نسبة الحضور': t ? Math.round(pm.present / t * 100) + '%' : ''
        };
      });
  }

  function toCSV(rows) {
    if (!rows.length) return '';
    var keys = Object.keys(rows[0]);
    function esc(v) {
      var s = String(v == null ? '' : v);
      return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }
    var lines = [keys.map(esc).join(',')].concat(rows.map(function (r) {
      return keys.map(function (k) { return esc(r[k]); }).join(',');
    }));
    return '﻿' + lines.join('\r\n');
  }

  /* ---------- Birthdays and age ---------- */

  function nextBirthday(birthISO, today) {
    var b = parseISO(birthISO);
    if (!b) return null;
    var t0 = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    var next = new Date(t0.getFullYear(), b.getMonth(), b.getDate());
    if (next < t0) next = new Date(t0.getFullYear() + 1, b.getMonth(), b.getDate());
    return { date: next, days: Math.round((next - t0) / DAY), turns: next.getFullYear() - b.getFullYear() };
  }

  function upcomingBirthdays(members, today, withinDays) {
    return members
      .map(function (m) {
        var nb = nextBirthday(m.birthDate, today);
        return nb ? Object.assign({ member: m }, nb) : null;
      })
      .filter(function (x) { return x && x.days <= withinDays; })
      .sort(function (a, b) { return a.days - b.days; });
  }

  function ageOn(birthISO, today) {
    var b = parseISO(birthISO);
    if (!b) return null;
    var a = today.getFullYear() - b.getFullYear();
    var m = today.getMonth() - b.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < b.getDate())) a--;
    return a;
  }

  /* ---------- Search ---------- */

  function filterMembers(members, f) {
    var q = normalizeText(f.q);
    return members.filter(function (m) {
      if (f.sectionId && m.sectionId !== f.sectionId) return false;
      if (f.classId && m.classId !== f.classId) return false;
      if (q && normalizeText(m.name + ' ' + m.phone + ' ' + m.address).indexOf(q) < 0) return false;
      return true;
    }).sort(byName);
  }

  /* ---------- Backup ---------- */

  function exportBackup(data, now) {
    var out = normalizeData(data);
    out.exportedAt = (now || new Date()).toISOString();
    return JSON.stringify(out, null, 2);
  }

  function importBackup(text) {
    var obj;
    try { obj = JSON.parse(text); } catch (e) { return { ok: false, error: 'الملف ليس JSON صحيحًا' }; }
    var err = validateData(obj);
    if (err) return { ok: false, error: err };
    return { ok: true, data: normalizeData(obj) };
  }

  /* ---------- Fridays ---------- */

  function isFriday(iso) {
    var d = parseISO(iso);
    return !!d && d.getDay() === 5;
  }

  // The Friday we are "in": today if it is Friday, otherwise the next Friday.
  // Switches automatically to the following Friday on Saturday.
  function fridayOf(now) {
    now = now || new Date();
    var d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    d.setDate(d.getDate() + ((5 - d.getDay() + 7) % 7));
    return d;
  }

  function currentFriday(now) { return isoDate(fridayOf(now)); }

  // Members marked absent in each of the last two recorded Friday sessions for their scope.
  function consecutiveAbsentees(data, now) {
    var todayKey = isoDate(now || new Date());
    var out = [];
    data.members.forEach(function (m) {
      var fr = data.attendance.filter(function (s) {
        return s.sectionId === m.sectionId && (!s.classId || s.classId === m.classId) &&
          !!s.marks[m.id] && s.date <= todayKey && isFriday(s.date);
      }).sort(function (a, b) { return b.date.localeCompare(a.date); }).slice(0, 2);
      if (fr.length === 2 && fr.every(function (s) { return s.marks[m.id] === 'absent'; })) {
        out.push({ member: m, dates: fr.map(function (s) { return s.date; }) });
      }
    });
    return out.sort(function (a, b) { return byName(a.member, b.member); });
  }

  return {
    STATUS: STATUS,
    FORMAT: FORMAT,
    DEFAULT_SECTIONS: DEFAULT_SECTIONS,
    emptyData: emptyData,
    normalizeData: normalizeData,
    validateData: validateData,
    validateMember: validateMember,
    addMember: addMember,
    updateMember: updateMember,
    deleteMember: deleteMember,
    addSection: addSection,
    renameSection: renameSection,
    deleteSection: deleteSection,
    addClass: addClass,
    renameClass: renameClass,
    deleteClass: deleteClass,
    findSession: findSession,
    membersInScope: membersInScope,
    saveSession: saveSession,
    deleteSession: deleteSession,
    rangeFor: rangeFor,
    buildReport: buildReport,
    memberRows: memberRows,
    toCSV: toCSV,
    nextBirthday: nextBirthday,
    upcomingBirthdays: upcomingBirthdays,
    ageOn: ageOn,
    filterMembers: filterMembers,
    normalizeText: normalizeText,
    exportBackup: exportBackup,
    importBackup: importBackup,
    parseISO: parseISO,
    isoDate: isoDate,
    isFriday: isFriday,
    fridayOf: fridayOf,
    currentFriday: currentFriday,
    consecutiveAbsentees: consecutiveAbsentees
  };
});
